# Deploy Guide - CafeCata

## Opción A - Deploy rápido (Frontend en Vercel + Backend en Render)

### Backend (Render with Docker)
1. Crear cuenta en Render.
2. Nuevo servicio -> Web Service -> Conectar repo GitHub -> seleccionar `backend` -> Usar Docker.
3. Variables de entorno en Render:
   - DATABASE_URL: postgresql://user:pass@host:5432/dbname
   - SECRET_KEY: <clave>
4. Añadir database en ElephantSQL o Render Postgres; usar credenciales en DATABASE_URL.
5. Desplegar, revisar logs.

### Frontend (Vercel)
1. Crear cuenta en Vercel.
2. Import project -> seleccionar `frontend` carpeta.
3. Set env var VITE_API_URL -> https://<backend-url>/api
4. Deploy.

## Opción B - Todo en Docker Compose (servidor VPS)
1. VPS con Docker instalado (DigitalOcean, AWS EC2, etc.).
2. Subir proyecto.
3. Configurar `.env.production` con credenciales de Postgres.
4. `docker-compose up --build -d`
5. Configurar Nginx o Traefik como reverse-proxy y certificados SSL (Let's Encrypt).

## Post-deploy
- Crear usuario admin: `POST /api/users` y asignar role `admin`.
- Probar generación de PDF desde interfaz.
- Habilitar backups para la base de datos.
