import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import LotsList from './pages/LotsList'
import LotForm from './pages/LotForm'
import CuppingForm from './pages/CuppingForm'

function App(){
  const token = localStorage.getItem('cafecata_token')
  return (
    <Routes>
      <Route path="/login" element={<Login/>} />
      <Route path="/" element={token ? <Dashboard/> : <Navigate to="/login" replace/>} />
      <Route path="/lots" element={token ? <LotsList/> : <Navigate to="/login" replace/>} />
      <Route path="/lots/new" element={token ? <LotForm/> : <Navigate to="/login" replace/>} />
      <Route path="/lots/:id/cupping" element={token ? <CuppingForm/> : <Navigate to="/login" replace/>} />
    </Routes>
  )
}

export default App
