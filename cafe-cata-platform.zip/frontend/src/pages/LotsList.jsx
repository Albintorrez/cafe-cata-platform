import React, {useEffect, useState} from 'react'
import api from '../services/api'
import { Link } from 'react-router-dom'

export default function LotsList(){
  const [lots,setLots]=useState([])
  useEffect(()=>{api.get('/lots').then(r=>setLots(r.data))},[])
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold">Lotes</h2>
      <table className="w-full mt-4 border-collapse bg-white shadow rounded">
        <thead><tr className="bg-gray-100"><th className="p-2">Nombre</th><th className="p-2">Variedad</th><th className="p-2">Proceso</th><th className="p-2">Acciones</th></tr></thead>
        <tbody>
          {lots.map(l=> (
            <tr key={l.id} className="border-t">
              <td className="p-2">{l.name}</td>
              <td className="p-2">{l.variety}</td>
              <td className="p-2">{l.process}</td>
              <td className="p-2">
                <Link to={`/lots/${l.id}/cupping`} className="underline mr-2">Catar</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
