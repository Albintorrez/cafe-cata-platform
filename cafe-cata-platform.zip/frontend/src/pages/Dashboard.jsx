import React from 'react'
import { Link } from 'react-router-dom'

export default function Dashboard(){
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="mt-4">
        <Link to="/lots" className="mr-4 underline">Lotes</Link>
        <Link to="/lots/new" className="underline">Crear Lote</Link>
      </div>
    </div>
  )
}
