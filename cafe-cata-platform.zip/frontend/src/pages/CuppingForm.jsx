import React, {useState, useEffect} from 'react'
import api from '../services/api'
import { useParams, useNavigate } from 'react-router-dom'
import RadarCupping from '../components/RadarCupping'

export default function CuppingForm(){
  const { id } = useParams()
  const [lot, setLot] = useState(null)
  const [scores, setScores] = useState({aroma:7, flavor:7, aftertaste:7, acidity:7, body:7, balance:7})
  const [notes, setNotes] = useState('')
  const nav = useNavigate()

  useEffect(()=>{ api.get('/lots').then(r=>{ const found = r.data.find(x=>x.id===Number(id)); setLot(found) }) },[])

  const submit = async ()=>{
    const total = Object.values(scores).reduce((a,b)=>a+b,0)/6
    await api.post('/cuppings', {lot_id: Number(id), user_id: 1, scores, notes, score_total: total})
    alert('Cata guardada')
    nav('/lots')
  }

  const exportPdf = async ()=>{
    try{
      const res = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000/api') + `/reports/cupping/1` , {
        headers: { Authorization: `Bearer ${localStorage.getItem('cafecata_token')}` }
      })
      const blob = await res.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `cata_1.pdf`
      document.body.appendChild(a)
      a.click()
      a.remove()
    }catch(e){
      alert('Error al exportar PDF')
    }
  }

  if(!lot) return <div className="p-6">Cargando lote...</div>

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold">Catar: {lot.name}</h2>
      <RadarCupping data={scores} setData={setScores} />
      <textarea className="w-full h-24 mt-4 p-2 border rounded" value={notes} onChange={e=>setNotes(e.target.value)} />
      <div className="mt-2 flex gap-2">
        <button onClick={submit} className="px-4 py-2 bg-blue-600 text-white rounded">Guardar Cata</button>
        <button onClick={exportPdf} className="px-4 py-2 bg-gray-600 text-white rounded">Exportar PDF</button>
      </div>
    </div>
  )
}
