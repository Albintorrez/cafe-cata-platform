import React, {useState} from 'react'
import api from '../services/api'
import { useNavigate } from 'react-router-dom'
import jwt_decode from 'jwt-decode'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const nav = useNavigate()

  const submit = async (e)=>{
    e.preventDefault()
    try{
      const form = new URLSearchParams()
      form.append('username', email)
      form.append('password', password)
      const res = await api.post('/token', form)
      localStorage.setItem('cafecata_token', res.data.access_token)
      try{
        const decoded = jwt_decode(res.data.access_token)
        localStorage.setItem('cafecata_user', JSON.stringify({email: decoded.sub}))
      }catch(e){}
      nav('/')
    }catch(err){
      alert('Error al ingresar')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={submit} className="p-6 border rounded bg-white shadow">
        <h2 className="text-xl font-bold mb-4">Ingresar a CafeCata</h2>
        <input className="block mb-2 p-2 border rounded w-80" placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input type="password" className="block mb-2 p-2 border rounded w-80" placeholder="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="px-4 py-2 bg-blue-600 text-white rounded">Entrar</button>
      </form>
    </div>
  )
}
