import React, {useState} from 'react'
import api from '../services/api'
import { useNavigate } from 'react-router-dom'

export default function LotForm(){
  const [name,setName]=useState('')
  const [variety,setVariety]=useState('')
  const [process,setProcess]=useState('')
  const nav = useNavigate()

  const submit = async (e)=>{
    e.preventDefault()
    try{
      await api.post('/lots', {name, producer_id:1, variety, process})
      nav('/lots')
    }catch(err){
      alert('Error creando lote')
    }
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold">Crear Lote</h2>
      <form onSubmit={submit} className="mt-4 bg-white p-4 rounded shadow">
        <input placeholder="Nombre" value={name} onChange={e=>setName(e.target.value)} className="block mb-2 p-2 border rounded w-full" />
        <input placeholder="Variedad" value={variety} onChange={e=>setVariety(e.target.value)} className="block mb-2 p-2 border rounded w-full" />
        <input placeholder="Proceso" value={process} onChange={e=>setProcess(e.target.value)} className="block mb-2 p-2 border rounded w-full" />
        <button className="px-4 py-2 bg-green-600 text-white rounded">Guardar</button>
      </form>
    </div>
  )
}
