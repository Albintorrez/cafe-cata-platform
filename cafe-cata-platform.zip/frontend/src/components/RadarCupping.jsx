import React from 'react'
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts'

export default function RadarCupping({data, setData}){
  const keys = Object.keys(data)
  const chartData = keys.map(k=>({subject:k, A: data[k]}))
  return (
    <div className="flex gap-4 items-start">
      <RadarChart cx={150} cy={150} outerRadius={90} width={300} height={300} data={chartData}>
        <PolarGrid />
        <PolarAngleAxis dataKey="subject" />
        <PolarRadiusAxis />
        <Radar name="Scores" dataKey="A" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
      </RadarChart>
      <div>
        {keys.map(k=> (
          <div key={k} className="mb-2">
            <label className="block">{k}</label>
            <input type="range" min={0} max={10} value={data[k]} onChange={e=>setData({...data, [k]: Number(e.target.value)})} />
            <span className="ml-2">{data[k]}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
