from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from .database import SessionLocal
from . import models
import io
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import matplotlib.pyplot as plt

router = APIRouter()

def generate_radar_image(scores: dict):
    labels = list(scores.keys())
    values = [scores[k] for k in labels]
    N = len(labels)
    angles = [n / float(N) * 2 * 3.1415926535 for n in range(N)]
    values += values[:1]
    angles += angles[:1]
    fig = plt.figure(figsize=(4,4))
    ax = fig.add_subplot(111, polar=True)
    ax.plot(angles, values)
    ax.fill(angles, values, alpha=0.25)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    buf = io.BytesIO()
    plt.savefig(buf, format='PNG', bbox_inches='tight')
    plt.close(fig)
    buf.seek(0)
    return buf

@router.get('/reports/cupping/{c_id}')
def report_cupping(c_id: int):
    db: Session = SessionLocal()
    cupping = db.query(models.Cupping).filter(models.Cupping.id==c_id).first()
    if not cupping:
        raise HTTPException(status_code=404, detail='Cupping not found')
    lot = cupping.lot
    imgbuf = generate_radar_image(cupping.scores)
    pdf_buf = io.BytesIO()
    p = canvas.Canvas(pdf_buf, pagesize=A4)
    p.setFont('Helvetica-Bold', 14)
    p.drawString(40, 820, f'Cata ID: {cupping.id} - Lote: {lot.name}')
    p.setFont('Helvetica', 10)
    p.drawString(40, 800, f'Productor ID: {lot.producer_id}  Variedad: {lot.variety}  Proceso: {lot.process}')
    p.drawString(40, 780, f'Puntaje Total: {cupping.score_total:.2f}')
    p.drawInlineImage(imgbuf, 40, 540, width=300, height=300)
    p.drawString(40, 520, 'Notas:')
    textobject = p.beginText(40, 500)
    for line in (cupping.notes or '').split('\n'):
        textobject.textLine(line[:200])
    p.drawText(textobject)
    p.showPage()
    p.save()
    pdf_buf.seek(0)
    return StreamingResponse(pdf_buf, media_type='application/pdf', headers={'Content-Disposition':f'attachment; filename=cata_{c_id}.pdf'})
