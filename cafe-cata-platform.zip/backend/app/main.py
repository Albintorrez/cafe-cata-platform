from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from . import models, schemas, crud, auth
from .database import engine, Base, SessionLocal
from fastapi.security import OAuth2PasswordRequestForm

Base.metadata.create_all(bind=engine)
app = FastAPI(title="CafeCata API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db_dep():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post('/api/users', response_model=schemas.UserOut)
def register_user(user: schemas.UserCreate, db: Session = Depends(get_db_dep)):
    existing = db.query(models.User).filter(models.User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail='User already exists')
    return crud.create_user(db, user)

@app.post('/api/token', response_model=schemas.Token)
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db_dep)):
    user = auth.authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=401, detail='Incorrect username or password')
    access_token = auth.create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

@app.get('/api/lots', response_model=list[schemas.LotOut])
def get_lots(db: Session = Depends(get_db_dep)):
    return crud.list_lots(db)

@app.post('/api/lots', response_model=schemas.LotOut)
def post_lot(lot: schemas.LotCreate, db: Session = Depends(get_db_dep), current_user: models.User = Depends(auth.get_current_user)):
    if current_user.role not in ('producer', 'admin'):
        raise HTTPException(status_code=403, detail='Not authorized')
    return crud.create_lot(db, lot)

@app.post('/api/roast_curves', response_model=schemas.RoastCurveOut)
def post_roast_curve(rc: schemas.RoastCurveCreate, db: Session = Depends(get_db_dep), current_user: models.User = Depends(auth.get_current_user)):
    return crud.create_roast_curve(db, rc)

@app.get('/api/roast_curves', response_model=list[schemas.RoastCurveOut])
def get_roast_curves(db: Session = Depends(get_db_dep)):
    return crud.list_roast_curves(db)

@app.post('/api/cuppings', response_model=schemas.CuppingOut)
def post_cupping(cupping: schemas.CuppingCreate, db: Session = Depends(get_db_dep), current_user: models.User = Depends(auth.get_current_user)):
    return crud.create_cupping(db, cupping)

@app.get('/api/lots/{lot_id}/cuppings', response_model=list[schemas.CuppingOut])
def get_cuppings_for_lot(lot_id: int, db: Session = Depends(get_db_dep)):
    return crud.list_cuppings_by_lot(db, lot_id)

from .reports import router as reports_router
app.include_router(reports_router, prefix='/api')
