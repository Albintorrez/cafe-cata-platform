from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
from datetime import datetime

class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str
    role: Optional[str] = 'producer'

class UserOut(BaseModel):
    id: int
    email: EmailStr
    name: str
    role: str
    created_at: datetime

    class Config:
        orm_mode = True

class LotCreate(BaseModel):
    name: str
    producer_id: int
    variety: Optional[str]
    process: Optional[str]
    altitude: Optional[int]
    humidity: Optional[float]
    notes: Optional[str]

class LotOut(LotCreate):
    id: int
    created_at: datetime
    class Config:
        orm_mode = True

class RoastCurveCreate(BaseModel):
    lot_id: int
    data: List[Dict[str, Any]]

class RoastCurveOut(RoastCurveCreate):
    id: int
    created_at: datetime
    class Config:
        orm_mode = True

class CuppingCreate(BaseModel):
    lot_id: int
    user_id: int
    scores: Dict[str, float]
    notes: Optional[str]
    score_total: float

class CuppingOut(CuppingCreate):
    id: int
    created_at: datetime
    class Config:
        orm_mode = True

class Token(BaseModel):
    access_token: str
    token_type: str
