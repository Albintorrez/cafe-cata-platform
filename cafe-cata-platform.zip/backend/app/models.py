from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from .database import Base
import datetime

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    name = Column(String)
    hashed_password = Column(String)
    role = Column(String, default="producer")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Lot(Base):
    __tablename__ = "lots"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    producer_id = Column(Integer, ForeignKey("users.id"))
    variety = Column(String)
    process = Column(String)
    altitude = Column(Integer)
    humidity = Column(Float)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    producer = relationship("User")

class RoastCurve(Base):
    __tablename__ = "roast_curves"
    id = Column(Integer, primary_key=True, index=True)
    lot_id = Column(Integer, ForeignKey("lots.id"))
    data = Column(JSON)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Cupping(Base):
    __tablename__ = "cuppings"
    id = Column(Integer, primary_key=True, index=True)
    lot_id = Column(Integer, ForeignKey("lots.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    scores = Column(JSON)
    notes = Column(Text)
    score_total = Column(Float)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    lot = relationship("Lot")
    user = relationship("User")
