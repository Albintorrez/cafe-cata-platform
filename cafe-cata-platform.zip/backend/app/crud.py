from sqlalchemy.orm import Session
from . import models, schemas
from .auth import get_password_hash

def create_user(db: Session, user: schemas.UserCreate):
    hashed = get_password_hash(user.password)
    db_user = models.User(email=user.email, name=user.name, hashed_password=hashed, role=user.role)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def create_lot(db: Session, lot: schemas.LotCreate):
    db_lot = models.Lot(**lot.dict())
    db.add(db_lot)
    db.commit()
    db.refresh(db_lot)
    return db_lot

def list_lots(db: Session):
    return db.query(models.Lot).all()

def create_roast_curve(db: Session, rc: schemas.RoastCurveCreate):
    db_rc = models.RoastCurve(lot_id=rc.lot_id, data=rc.data)
    db.add(db_rc)
    db.commit()
    db.refresh(db_rc)
    return db_rc

def list_roast_curves(db: Session):
    return db.query(models.RoastCurve).all()

def create_cupping(db: Session, c: schemas.CuppingCreate):
    db_c = models.Cupping(lot_id=c.lot_id, user_id=c.user_id, scores=c.scores, notes=c.notes, score_total=c.score_total)
    db.add(db_c)
    db.commit()
    db.refresh(db_c)
    return db_c

def list_cuppings_by_lot(db: Session, lot_id: int):
    return db.query(models.Cupping).filter(models.Cupping.lot_id == lot_id).all()
