# CafeCata - Plataforma de cata de café (MVP)

Proyecto completo: backend (FastAPI), frontend (React + Tailwind), mobile (Expo - base), export PDF, Docker Compose y guía de deploy.

## Requisitos locales
- Docker & Docker Compose
- Node 18+, npm
- Python 3.10+

## Levantar en local con Docker Compose (modo producción mínima)
1. Copia el repo a tu máquina.
2. `docker-compose up --build`
3. Backend en `http://localhost:8000` y frontend en `http://localhost:5173`.

## Levantar en local sin Docker (desarrollo)
### Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Endpoints principales
- `POST /api/users` - registrar usuario
- `POST /api/token` - login (form-urlencoded)
- `GET /api/lots` - listar lotes
- `POST /api/lots` - crear lote
- `POST /api/cuppings` - crear cata
- `GET /api/lots/{lot_id}/cuppings` - listar catas por lote
- `GET /api/reports/cupping/{c_id}` - descargar PDF de cata

## Deploy recomendado (paso a paso)
Ver `DEPLOY_GUIDE.md` para instrucciones detalladas.
